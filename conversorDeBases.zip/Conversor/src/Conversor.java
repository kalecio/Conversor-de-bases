import java.util.Scanner;

public class Conversor {

	public String toDecimal(String numero, int base) {
		String str = "";
		numero = numero.toUpperCase();
		int retorno = 0;
		int cont = 0;
		while (cont < numero.length()) {
			if (numero.charAt(cont) == 'A') {
				str += 10;
				int k = Integer.parseInt(str);
				retorno = base * retorno + k;
				str = "";
				cont++;
			} else if (numero.charAt(cont) == 'B') {
				str += 11;
				int k = Integer.parseInt(str);
				retorno = base * retorno + k;
				str = "";
				cont++;
			} else if (numero.charAt(cont) == 'C') {
				str += 12;
				int k = Integer.parseInt(str);
				retorno = base * retorno + k;
				str = "";
				cont++;
			} else if (numero.charAt(cont) == 'D') {
				str += 13;
				int k = Integer.parseInt(str);
				retorno = base * retorno + k;
				str = "";
				cont++;
			} else if (numero.charAt(cont) == 'E') {
				str += 14;
				int k = Integer.parseInt(str);
				retorno = base * retorno + k;
				str = "";
				cont++;
			} else if (numero.charAt(cont) == 'F') {
				str += 15;
				int k = Integer.parseInt(str);
				retorno = base * retorno + k;
				str = "";
				cont++;
			} else {
				str += numero.charAt(cont);
				int k = Integer.parseInt(str);
				retorno = base * retorno + k;
				str = "";
				cont++;
			}
		}
		str += retorno;
		return str;
	}

	public String outraBase(String numero, int base) {
		String resultado = "";
		int k = Integer.parseInt(numero);
		int resto = k % base;

		if (k == 0) {
			return "";
		} else {
			if(resto==10){
				resultado = "A";
			}
			else if(resto==11){
				resultado = "B";
			}
			else if(resto==12){
				resultado = "C";
			}
			else if(resto==13){
				resultado = "D";
			}
			else if(resto==14){
				resultado = "E";
			}
			else if(resto==15){
				resultado = "F";
			}
			else{
				resultado = resto + resultado;
			}
			
			return outraBase(Integer.toString(k / base), base) + resultado;
		}
	}

	

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		Conversor b = new Conversor();
		System.out.println(b.outraBase(a,8));
	}
}
